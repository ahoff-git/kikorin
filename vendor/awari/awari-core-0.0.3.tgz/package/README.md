# @awari/core

Reusable TypeScript library for Awari's peer-to-peer networking logic. Depends on `@awari/protocol` for shared message types and constants. Networking behavior is not yet implemented — this package currently only scaffolds the buildable structure.

See [specs/awari-core](../../specs/awari-core/README.md) for design notes.
