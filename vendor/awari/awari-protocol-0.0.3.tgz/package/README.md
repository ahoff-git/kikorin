# @awari/protocol

Shared message contracts, types, schemas, and protocol constants for Awari. Consumed by both `bootstrap-service` and `@awari/core` so peers and services agree on a single source of truth for wire formats. Contains no networking, database, or transport logic — types and constants only.

See [specs/awari-protocol](../../specs/awari-protocol/README.md) for design notes.
