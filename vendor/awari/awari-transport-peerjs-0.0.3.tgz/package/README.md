# @awari/transport-peerjs

PeerJS-backed implementation of `@awari/core`'s `Transport` interface, using PeerJS's default public broker for WebRTC signaling. This is the only package that knows PeerJS exists — everything above it (routing, connection planning, ranking) depends only on the `Transport` interface, so a different transport can be swapped in later without touching them.

See [ADR 0008](../../specs/decisions/0008-peerjs-transport.md) for the reasoning, including why this can be built and type-checked here but not exercised by automated tests (it needs a real browser WebRTC environment).
